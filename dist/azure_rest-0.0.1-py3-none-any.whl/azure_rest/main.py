from azure_rest.cost import *
from azure_rest.access_token import *
from azure_rest.metrics import *


def main():
    pass

if __name__ == "__main__":
  main()
